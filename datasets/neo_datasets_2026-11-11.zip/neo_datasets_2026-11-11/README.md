# Datasets on which the asteroid's-view method outperformed the baselines

From "The Asteroid's Point of View" (Ch. Satwik, Devieswar Kancheti). Both files are public NASA/JPL data, downloaded on 11 November 2026 by `src/fetch_data.py`; the exact download times and filters are in `provenance.json`.

## 1. `sbdb_neo.csv`: NASA/JPL Small-Body Database, every near-Earth asteroid

- Source: SBDB Query API, https://ssd-api.jpl.nasa.gov/sbdb_query.api (documentation: https://ssd-api.jpl.nasa.gov/doc/sbdb_query.html)
- Query: `sb-group=neo`, `sb-kind=a`, `full-prec=true`
- Rows: 43,025 asteroids. The 42,888 that have both an Earth MOID and a hazard flag (2,551 hazardous) form the evaluation set.
- Label: `pha` (JPL's flag, `Y`/`N`), defined as MOID ≤ 0.05 au and H ≤ 22.
- Columns used:
  - `pdes`: designation
  - `a`, `e`, `i`, `om`, `w`: the orbit (au; angles in degrees)
  - `H`: absolute magnitude
  - `sigma_a` … `sigma_w`: 1σ uncertainties of the orbit
  - `condition_code`: orbit quality, 0 = best, 9 = worst
  - `first_obs`: first observation, used for the temporal split
  - `moid`: JPL's MOID, used only for evaluation and never as an input
- Results:

  | Method | Accuracy | F1 |
  |---|---|---|
  | Training-free path rule (5-fold over asteroids) | 99.86% | 0.989 |
  | Best learned model without the MOID column (LightGBM, path + kernels) | 99.71% | 0.976 |
  | Learned model on the raw orbit only | 98.38% | 0.862 |
  | Best published F1 on a full JPL catalogue (Jacques 2025) | — | 0.37 |

  A random forest that is given JPL's own MOID column, the quantity that defines the label, only matches the rule: 99.87% accuracy and F1 0.989.

## 2. `cad_earth.csv`: NASA/JPL Close-Approach Data (the "Earth's view" used by prior work)

- Source: Close-Approach Data API, https://ssd-api.jpl.nasa.gov/cad.api (documentation: https://ssd-api.jpl.nasa.gov/doc/cad.html)
- Query: `body=Earth`, `neo=true`, `dist-max=0.5` au, 1910-01-01 to 2024-12-31, fetched in 5-year chunks
- Rows: 306,903 approaches. The 306,590 that belong to a labelled asteroid (join `cad.des = sbdb.pdes`) cover 36,817 asteroids, with a median of 4 approaches each.
- Label: the asteroid's `pha` flag from `sbdb_neo.csv`, the same for all of its rows.
- Columns used:
  - `des`: designation
  - `cd`: close-approach date
  - `dist`: miss distance (au)
  - `v_rel`: relative velocity (km/s)
  - `h`: absolute magnitude

  Prior-work features: H, the diameter range from H, relative velocity and miss distance.
- Results, on identical asteroid-grouped folds:

  | Method | Accuracy | F1 |
  |---|---|---|
  | Best Earth's-view baseline | 92.63% | 0.428 |
  | Training-free path rule | 99.79% | 0.988 |
  | Always answering "not hazardous" | 91.26% | — |

## Not included

The Kaggle table `shrutimehta/nasa-asteroids-classification` (CC0, https://www.kaggle.com/datasets/shrutimehta/nasa-asteroids-classification) gave a tie, not a win: 99.42% for both the strongest published model, split by asteroid, and the training-free rule.

## Rebuilding

Run `python src/fetch_data.py`, or `./run_all.sh` for everything. JPL updates its catalogue daily, so fresh downloads change the numbers slightly.
